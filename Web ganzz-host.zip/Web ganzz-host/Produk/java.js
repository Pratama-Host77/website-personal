function addToCart() {
  alert("Tunggu Sebentar Yaa😁");
}
