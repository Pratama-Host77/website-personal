document.getElementById('tombol-klik').addEventListener('click', function() {
    alert('Tombol diklik!');
});